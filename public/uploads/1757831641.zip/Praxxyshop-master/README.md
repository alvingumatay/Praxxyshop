# Praxxyshop
**#installation guidelines:**
1. download xampp
2. excute the xampp.exe
3. open  the  xampp and locate the htdocs folder drag and copy the file name "Praxxyshop"
4. open file name Praxxshop and find the database then db file copy the  "product.sql"
5. execute the xampp server control panel and on the Apache for Website and Mysql for the database
6. in google browser type "http://localhost/phpmyadmin/"
7. create new database "product"
8. then find "Import" then "choose file" then select product .sql. then scroll down and click "go."
9. in google browser type "http://localhost/Praxxyshop/public/login"
