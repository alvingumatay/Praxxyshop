<?php

namespace App\Http\Controllers\Admin;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;


class ProductController extends Controller
{
    public function create()
    {
        
        return view('admin.create');
    }


     public function edit($id)
    {
        $product = Product::find($id);
        return view('admin.edit', compact('product'));
    }
     public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $product->name = $request->input('name');
         $product->category = $request->input('category');
        $product->description = $request->input('description');
       
         if ($request->hasFile('product_image')) {
        // Delete old image if it exists
        if ($product->product_image && file_exists(public_path('./uploads/' . $product->product_image))) {
            unlink(public_path('./uploads/' . $product->product_image));
        }

        // Upload new image
        $imageName = time() . '.' . $request->product_image->extension();
        $request->product_image->move(public_path('uploads'), $imageName);
        $product->product_image = $imageName;
        }



         if($request->hasfile('product_image')) {
        $imageName = time() . '.' . $request->product_image->extension();
        $request->product_image->move(public_path('uploads'), $imageName);
        $product->product_image =  $imageName;
    }  
        $product->date = $request->input('date');
        $product->time = $request->input('time');
        $product->update();
        return redirect('/dashboard')->with('status','Student Updated Successfully');
    }

    public function destroy($id)
    {
        $product = Product::find($id); // Find the post by its ID
        $product->delete(); // Delete the found post

        return redirect('/dashboard')->with('success', 'Post deleted successfully.');
    }

    public function store(Request $request)
    {


        $product = new Product;
        $product->name = $request->input('name');
        $product->category = $request->input('category');
        $product->description = $request->input('description'); 
        $product->product_image = $request->input('product_image');
          if($request->hasfile('product_image')) {
        $imageName = time() . '.' . $request->product_image->extension();
        $request->product_image->move(public_path('uploads'), $imageName);
        $product->product_image =  $imageName;
    }  
        $product->date = $request->input('date');
        $product->time = $request->input('time');
        
        $product->save();
        return redirect('/dashboard')->with('status','New Product Added Successfully');
    }


     public function index()
    {
        $product = Product::all();
        return view('admin.index', compact('product'));
    }


   
}
