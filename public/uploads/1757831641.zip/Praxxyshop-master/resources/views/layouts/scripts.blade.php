
<script src="{{ asset('frontend/js2/bootstrap.js')}}"></script>
<script src="{{ asset('frontend/js2/jquery.min.js')}}"></script>
<script src="{{ asset('frontend/js2/dropdown.js')}}"></script>
<script src="{{ asset('frontend/js2/jquery.dataTables.js')}}"></script>
<script src="{{ asset('frontend/js2/custom.js')}}"></script>
<script src="{{ asset('frontend/js2/bootstrap.js')}}"></script>
<script src="{{ asset('frontend/js2/bootstrap.js')}}"></script>

<script type = "text/javascript">
	
	$(document).ready(function() {
		$('#table').DataTable();
		$('#table1').DataTable();
	});
	
</script>